package elevatornew;

class Floor {
	private int num=10;

	
	public  int getNum() {
		return num;
	}
	
}










