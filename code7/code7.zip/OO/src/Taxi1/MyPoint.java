package Taxi1;

public class MyPoint {
	int x;
	int y;
	public MyPoint(int x,int y){
		this.x=x;
		this.y=y;
	}
}
